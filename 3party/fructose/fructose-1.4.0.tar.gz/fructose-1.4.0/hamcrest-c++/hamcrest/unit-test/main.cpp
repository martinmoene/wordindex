#include "UnitTest++.h"

int main (int /*argc*/, const char* /*argv*/[])
{
    return UnitTest::RunAllTests();
}
